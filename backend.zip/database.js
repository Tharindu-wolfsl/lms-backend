var mysql = require('mysql');
var conn = mysql.createConnection({
  host: 'admin.passmelearn.com', // assign your host name
  user: 'passmevi_lms',      //  assign your database username
  password: 'Passme.lk',      // assign your database password
  database: 'passmevi_lms' // assign database Name
}); 
conn.connect(function(err) {
  if (err) throw err;
  console.log('Database is connected successfully !');
});
module.exports = conn;