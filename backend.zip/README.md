//How run project

1.  Go to backend folder using terminal
2.  Run 'npm install' to install node modules
3.  Open My sql server and import 'lms.sql' file in backend folder
4.  Run mysql server
5.  Run 'npm run devStart' in terminal to run project
6.  Go to browser and paste "http://localhost:3001/" in address bar
7.  Now you can add new user or login using username:'admin@net.com ' password:'123'
